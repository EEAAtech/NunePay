/****** Object:  Table [dbo].[__MigrationHistory]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__MigrationHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ContextKey] [nvarchar](300) NOT NULL,
	[Model] [varbinary](max) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK_dbo.__MigrationHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC,
	[ContextKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Advance]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Advance](
	[AdvanceID] [int] IDENTITY(1,1) NOT NULL,
	[EmpID] [int] NOT NULL,
	[AdvDate] [date] NOT NULL,
	[Amount] [money] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[AdvanceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Allowance]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Allowance](
	[AllowanceID] [int] IDENTITY(1,1) NOT NULL,
	[ATID] [int] NOT NULL,
	[WEF] [date] NOT NULL,
	[EmpTypeID] [int] NOT NULL,
	[PercOfWage] [money] NULL,
	[Amount] [money] NULL,
PRIMARY KEY CLUSTERED 
(
	[AllowanceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AllowanceTypes]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllowanceTypes](
	[ATID] [int] IDENTITY(1,1) NOT NULL,
	[AllowanceType] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ATID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetRoles]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoles](
	[Id] [nvarchar](128) NOT NULL,
	[Name] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserClaims]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](128) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_dbo.AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserLogins]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserLogins](
	[LoginProvider] [nvarchar](128) NOT NULL,
	[ProviderKey] [nvarchar](128) NOT NULL,
	[UserId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
	[LoginProvider] ASC,
	[ProviderKey] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserRoles]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserRoles](
	[UserId] [nvarchar](128) NOT NULL,
	[RoleId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUsers]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUsers](
	[Id] [nvarchar](128) NOT NULL,
	[Email] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NOT NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NOT NULL,
	[TwoFactorEnabled] [bit] NOT NULL,
	[LockoutEndDateUtc] [datetime] NULL,
	[LockoutEnabled] [bit] NOT NULL,
	[AccessFailedCount] [int] NOT NULL,
	[UserName] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Attendance]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Attendance](
	[EmpID] [int] NOT NULL,
	[LeaveDate] [date] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC,
	[LeaveDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Bonus]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Bonus](
	[EmpID] [int] NOT NULL,
	[Year] [int] NOT NULL,
	[SysBonus] [money] NULL,
	[UsrBonus] [money] NULL,
	[Frozen] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC,
	[Year] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Config]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Config](
	[Id] [int] NOT NULL,
	[BonusPerc] [decimal](18, 2) NULL,
	[DocExpirePreWarning] [int] NULL,
	[RowsPerPage] [int] NOT NULL,
	[ImageSavePath] [varchar](150) NULL,
	[DefaultBank] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[DailyAllowance]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DailyAllowance](
	[EmpID] [int] NOT NULL,
	[AllowDate] [date] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC,
	[AllowDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EDocTypes]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EDocTypes](
	[EDocTypeID] [int] IDENTITY(1,1) NOT NULL,
	[EDocType] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EDocTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EmpDocs]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmpDocs](
	[EDID] [int] IDENTITY(1,1) NOT NULL,
	[EmpID] [int] NOT NULL,
	[EDocTypeID] [int] NOT NULL,
	[Image] [varchar](100) NULL,
	[ExpiryDate] [date] NULL,
	[Renewed] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EDID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Employees]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employees](
	[EmpID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](250) NOT NULL,
	[NickName] [varchar](50) NULL,
	[EmpTypeID] [int] NOT NULL,
	[JobTitle] [varchar](150) NULL,
	[Mobile] [varchar](50) NULL,
	[EmContactNo] [varchar](50) NULL,
	[EmContactName] [varchar](250) NULL,
	[EmContactReln] [varchar](50) NULL,
	[RegBankAc] [varchar](50) NULL,
	[NRegBankAc] [varchar](50) NULL,
	[NRegBank] [varchar](50) NULL,
	[NRegIFSC] [varchar](50) NULL,
	[BonusPayMonth] [tinyint] NOT NULL,
	[PFno] [varchar](50) NULL,
	[ESIno] [varchar](50) NULL,
	[CatAB] [char](1) NULL,
	[IsHDFC] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EmploymentHistory]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmploymentHistory](
	[EHID] [int] IDENTITY(1,1) NOT NULL,
	[EmpID] [int] NOT NULL,
	[JoinDate] [date] NOT NULL,
	[RegistrationDate] [date] NULL,
	[ExitDate] [date] NULL,
	[ExitReason] [varchar](max) NULL,
 CONSTRAINT [PK_EmploymentHistory] PRIMARY KEY CLUSTERED 
(
	[EHID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EmpTypes]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmpTypes](
	[EmpTypeID] [int] IDENTITY(1,1) NOT NULL,
	[EmpType] [varchar](50) NOT NULL,
	[HasDailyAllowance] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Holidays]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Holidays](
	[HoliDate] [date] NOT NULL,
	[Holiday] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[HoliDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LoanPay]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoanPay](
	[LoanPayID] [int] IDENTITY(1,1) NOT NULL,
	[LoanID] [int] NOT NULL,
	[GenMonth] [int] NOT NULL,
	[GenYear] [int] NOT NULL,
	[Amount] [money] NOT NULL,
	[Frozen] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[LoanPayID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Loans]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Loans](
	[LoanID] [int] IDENTITY(1,1) NOT NULL,
	[EmpID] [int] NOT NULL,
	[LoanDate] [date] NOT NULL,
	[Amount] [money] NOT NULL,
	[PayMonths] [int] NOT NULL,
	[PaidOff] [bit] NOT NULL,
	[Default] [bit] NOT NULL,
	[DefaultReason] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[LoanID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LoanSkip]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoanSkip](
	[LoanSkipID] [int] IDENTITY(1,1) NOT NULL,
	[LoanID] [int] NOT NULL,
	[PayDate] [date] NOT NULL,
	[Amount] [money] NOT NULL,
	[Reason] [varchar](150) NULL,
PRIMARY KEY CLUSTERED 
(
	[LoanSkipID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Payroll]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Payroll](
	[EmpID] [int] NOT NULL,
	[GenMonth] [int] NOT NULL,
	[GenYear] [int] NOT NULL,
	[GenDate] [date] NULL,
	[Wages] [money] NULL,
	[DaysWorked] [int] NULL,
	[Allowance] [money] NULL,
	[Advance] [money] NULL,
	[Bonus] [money] NULL,
	[LoanAmt] [money] NULL,
	[LoanCmt] [varchar](50) NULL,
	[AdjAmt] [money] NULL,
	[AdjRemark] [varchar](100) NULL,
	[Total] [money] NULL,
	[Frozen] [bit] NOT NULL,
	[BankName] [varchar](50) NULL,
	[BankAccount] [varchar](50) NULL,
	[Instructions] [varchar](max) NULL,
	[ExcludeExcel] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC,
	[GenMonth] ASC,
	[GenYear] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[PayrollAllowance]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PayrollAllowance](
	[EmpID] [int] NOT NULL,
	[GenMonth] [int] NOT NULL,
	[GenYear] [int] NOT NULL,
	[ATID] [int] NOT NULL,
	[Amount] [money] NULL,
	[Frozen] [bit] NOT NULL,
 CONSTRAINT [PK_PayrollAllowance] PRIMARY KEY CLUSTERED 
(
	[ATID] ASC,
	[EmpID] ASC,
	[GenMonth] ASC,
	[GenYear] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[PayrollRemarks]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PayrollRemarks](
	[EmpID] [int] NOT NULL,
	[GenMonth] [int] NOT NULL,
	[GenYear] [int] NOT NULL,
	[ExcludeFromExcel] [bit] NULL,
	[Remarks] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC,
	[GenMonth] ASC,
	[GenYear] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Wages]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Wages](
	[WageID] [int] IDENTITY(1,1) NOT NULL,
	[EmpID] [int] NOT NULL,
	[WEF] [date] NOT NULL,
	[Amount] [money] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[WageID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [RoleNameIndex]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [RoleNameIndex] ON [dbo].[AspNetRoles]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_UserId]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE NONCLUSTERED INDEX [IX_UserId] ON [dbo].[AspNetUserClaims]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_UserId]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE NONCLUSTERED INDEX [IX_UserId] ON [dbo].[AspNetUserLogins]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_RoleId]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE NONCLUSTERED INDEX [IX_RoleId] ON [dbo].[AspNetUserRoles]
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_UserId]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE NONCLUSTERED INDEX [IX_UserId] ON [dbo].[AspNetUserRoles]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UserNameIndex]    Script Date: 6/11/2017 5:25:59 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [UserNameIndex] ON [dbo].[AspNetUsers]
(
	[UserName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Bonus] ADD  DEFAULT ((0)) FOR [Frozen]
GO
ALTER TABLE [dbo].[Config] ADD  DEFAULT ((30)) FOR [RowsPerPage]
GO
ALTER TABLE [dbo].[EmpDocs] ADD  DEFAULT ((0)) FOR [Renewed]
GO
ALTER TABLE [dbo].[Employees] ADD  DEFAULT ((12)) FOR [BonusPayMonth]
GO
ALTER TABLE [dbo].[EmpTypes] ADD  DEFAULT ((0)) FOR [HasDailyAllowance]
GO
ALTER TABLE [dbo].[LoanPay] ADD  DEFAULT ((0)) FOR [Frozen]
GO
ALTER TABLE [dbo].[Loans] ADD  DEFAULT ((0)) FOR [PaidOff]
GO
ALTER TABLE [dbo].[Loans] ADD  DEFAULT ((0)) FOR [Default]
GO
ALTER TABLE [dbo].[Payroll] ADD  DEFAULT ((0)) FOR [Frozen]
GO
ALTER TABLE [dbo].[Payroll] ADD  DEFAULT ((0)) FOR [ExcludeExcel]
GO
ALTER TABLE [dbo].[PayrollAllowance] ADD  DEFAULT ((0)) FOR [Frozen]
GO
ALTER TABLE [dbo].[Advance]  WITH CHECK ADD  CONSTRAINT [FK_Advance_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Advance] CHECK CONSTRAINT [FK_Advance_ToEmps]
GO
ALTER TABLE [dbo].[Allowance]  WITH CHECK ADD  CONSTRAINT [FK_Allowance_ToAT] FOREIGN KEY([ATID])
REFERENCES [dbo].[AllowanceTypes] ([ATID])
GO
ALTER TABLE [dbo].[Allowance] CHECK CONSTRAINT [FK_Allowance_ToAT]
GO
ALTER TABLE [dbo].[Allowance]  WITH CHECK ADD  CONSTRAINT [FK_Allowance_ToEmpTypes] FOREIGN KEY([EmpTypeID])
REFERENCES [dbo].[EmpTypes] ([EmpTypeID])
GO
ALTER TABLE [dbo].[Allowance] CHECK CONSTRAINT [FK_Allowance_ToEmpTypes]
GO
ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[Attendance]  WITH CHECK ADD  CONSTRAINT [FK_Attendance_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Attendance] CHECK CONSTRAINT [FK_Attendance_ToEmps]
GO
ALTER TABLE [dbo].[Bonus]  WITH CHECK ADD  CONSTRAINT [FK_Bonus_ToEmployees] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Bonus] CHECK CONSTRAINT [FK_Bonus_ToEmployees]
GO
ALTER TABLE [dbo].[DailyAllowance]  WITH CHECK ADD  CONSTRAINT [FK_DailyAllowance_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[DailyAllowance] CHECK CONSTRAINT [FK_DailyAllowance_ToEmps]
GO
ALTER TABLE [dbo].[EmpDocs]  WITH CHECK ADD  CONSTRAINT [FK_EDocs_ToEdocTypes] FOREIGN KEY([EDocTypeID])
REFERENCES [dbo].[EDocTypes] ([EDocTypeID])
GO
ALTER TABLE [dbo].[EmpDocs] CHECK CONSTRAINT [FK_EDocs_ToEdocTypes]
GO
ALTER TABLE [dbo].[EmpDocs]  WITH CHECK ADD  CONSTRAINT [FK_EmpDocs_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[EmpDocs] CHECK CONSTRAINT [FK_EmpDocs_ToEmps]
GO
ALTER TABLE [dbo].[Employees]  WITH CHECK ADD  CONSTRAINT [FK_Employees_ToEmpTypes] FOREIGN KEY([EmpTypeID])
REFERENCES [dbo].[EmpTypes] ([EmpTypeID])
GO
ALTER TABLE [dbo].[Employees] CHECK CONSTRAINT [FK_Employees_ToEmpTypes]
GO
ALTER TABLE [dbo].[EmploymentHistory]  WITH CHECK ADD  CONSTRAINT [FK_EmploymentHistory_ToEmployees] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[EmploymentHistory] CHECK CONSTRAINT [FK_EmploymentHistory_ToEmployees]
GO
ALTER TABLE [dbo].[LoanPay]  WITH CHECK ADD  CONSTRAINT [FK_LoanPay_ToLoan] FOREIGN KEY([LoanID])
REFERENCES [dbo].[Loans] ([LoanID])
GO
ALTER TABLE [dbo].[LoanPay] CHECK CONSTRAINT [FK_LoanPay_ToLoan]
GO
ALTER TABLE [dbo].[Loans]  WITH CHECK ADD  CONSTRAINT [FK_Loans_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Loans] CHECK CONSTRAINT [FK_Loans_ToEmps]
GO
ALTER TABLE [dbo].[LoanSkip]  WITH CHECK ADD  CONSTRAINT [FK_LoanSkip_ToLoan] FOREIGN KEY([LoanID])
REFERENCES [dbo].[Loans] ([LoanID])
GO
ALTER TABLE [dbo].[LoanSkip] CHECK CONSTRAINT [FK_LoanSkip_ToLoan]
GO
ALTER TABLE [dbo].[Payroll]  WITH CHECK ADD  CONSTRAINT [FK_Payroll_ToEmployees] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Payroll] CHECK CONSTRAINT [FK_Payroll_ToEmployees]
GO
ALTER TABLE [dbo].[PayrollAllowance]  WITH CHECK ADD  CONSTRAINT [FK_PayrollAllow_ToEmployees] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[PayrollAllowance] CHECK CONSTRAINT [FK_PayrollAllow_ToEmployees]
GO
ALTER TABLE [dbo].[PayrollAllowance]  WITH CHECK ADD  CONSTRAINT [FK_PayrollAllowance_ToAT] FOREIGN KEY([ATID])
REFERENCES [dbo].[AllowanceTypes] ([ATID])
GO
ALTER TABLE [dbo].[PayrollAllowance] CHECK CONSTRAINT [FK_PayrollAllowance_ToAT]
GO
ALTER TABLE [dbo].[PayrollRemarks]  WITH CHECK ADD  CONSTRAINT [FK_PayrollRem_ToEmployees] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[PayrollRemarks] CHECK CONSTRAINT [FK_PayrollRem_ToEmployees]
GO
ALTER TABLE [dbo].[Wages]  WITH CHECK ADD  CONSTRAINT [FK_Wages_ToEmps] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employees] ([EmpID])
GO
ALTER TABLE [dbo].[Wages] CHECK CONSTRAINT [FK_Wages_ToEmps]
GO
/****** Object:  StoredProcedure [dbo].[FreezePayroll]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[FreezePayroll]
	@month int,
	@year int
AS
	--Freeze the Payroll
	UPDATE Payroll SET Frozen = 1
	WHERE  GenMonth=@month AND GenYear=@year AND Frozen = 0

	--Freeze the Bonus
	UPDATE b SET Frozen =1
	FROM Bonus b, Payroll p
	WHERE b.Year=@year
	AND b.EmpID=p.EmpID
	AND b.Year=p.GenYear
	AND p.GenMonth=@month
	AND COALESCE(p.Bonus,0)>0

	--Freeze the loan amount paid
	UPDATE LoanPay SET Frozen =1 
	WHERE  GenMonth=@month AND GenYear=@year AND Frozen = 0

	--Mark Loans as PaidOff whose paid amount equals the borrowed amount
	UPDATE l SET PaidOff = 1
	FROM Loans l 
	WHERE l.Amount <= (SELECT SUM(p.Amount) FROM LoanPay p WHERE p.LoanID=l.LoanID AND p.Frozen=1)

	--Freeze the PayrollAllowance table
	UPDATE PayrollAllowance SET Frozen =1 
	WHERE  GenMonth=@month AND GenYear=@year AND Frozen = 0

RETURN 0

GO
/****** Object:  StoredProcedure [dbo].[GenBonus]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GenBonus]

AS
	DECLARE @Bonus DECIMAL(18,2)

	SELECT @Bonus=BonusPerc FROM Config

	
	--;WITH CurrWage(Amount, WEF,EmpID)
	--AS
	--(SELECT Max(Amount), Max(WEF), EmpID FROM Wages WHERE WEF < GetDate() GROUP BY EmpID )
	--INSERT INTO Bonus(EmpID,Year,SysBonus)
	--SELECT e.EmpID, year(getdate()), (w.Amount*30)* (@Bonus/100)
	--FROM Employees e, EmploymentHistory eh, CurrWage w
	--WHERE e.EmpID = eh.EmpID
	--AND e.EmpID=w.EmpID
	--AND eh.ExitDate IS NULL --only for currently employed staff
	--AND e.EmpID not in (SELECT EmpID FROM Bonus WHERE Year = year(getdate()))

	INSERT INTO Bonus(EmpID,Year)
	SELECT e.EmpID, year(getdate())
	FROM Employees e, EmploymentHistory eh
	WHERE e.EmpID = eh.EmpID	
	AND eh.ExitDate IS NULL --only for currently employed staff
	AND e.EmpID not in (SELECT EmpID FROM Bonus WHERE [Year] = year(getdate()))

	UPDATE b SET b.SysBonus = (SELECT TOP 1 Amount from Wages w where w.WEF< getdate() AND e.EmpID=w.EmpID ORDER BY WEF desc)
	FROM Bonus b, Employees e
	WHERE b.EmpID=e.EmpID
	AND [Year] = year(getdate())

	--calculated as a percentage of wages of a 30 day month
	UPDATE Bonus SET SysBonus = (SysBonus*30) * (@Bonus/100)
	WHERE [Year] = year(getdate())
RETURN 0

GO
/****** Object:  StoredProcedure [dbo].[GenPayroll]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GenPayroll]
	@month int,
	@year int
AS
CREATE TABLE #Pay (
	[EmpID]       INT           NOT NULL,
	[Wages]       MONEY         NULL,
	[DaysWorked]  INT           NULL,
	[Allowance]   MONEY         NULL,
	[Advance]     MONEY         NULL,
	[BonusPayMonth]       INT         NULL,
	[Bonus]       MONEY         NULL,
	[LoanAmt]     MONEY         NULL,
	[LoanCmt]     VARCHAR (50)  NULL,
	[Total]       MONEY         NULL,
	[BankName]    VARCHAR (50)  NULL,
	[BankAccount] VARCHAR (50)  NULL
	)

	CREATE CLUSTERED INDEX [IX_Emp] ON #Pay (EmpID)
	
	DECLARE @dbank VARCHAR(50)
	DECLARE @FirstOfMonth Date

	SELECT @dbank = CONCAT('R',DefaultBank) FROM Config
	SET @FirstOfMonth=CAST(CAST(@year AS VARCHAR(4)) + '/' + CAST(@month AS VARCHAR(2)) + '/1' AS DATETIME)

	--First initialise the table from Employee master
	INSERT INTO #Pay(EmpID, BonusPayMonth ,BankAccount, BankName)
	SELECT e.EmpID, e.BonusPayMonth, 
	CASE WHEN e.IsHDFC = 0 THEN e.NRegBankAc ELSE e.RegBankAc END,
	CASE WHEN e.IsHDFC = 0 THEN CONCAT('N',e.NRegBank) ELSE @dbank END
	FROM Employees e, EmploymentHistory eh
	WHERE e.EmpID = eh.EmpID	
	AND eh.ExitDate IS NULL --only for currently employed staff
	
	--days worked is 30 - leaves taken
	Update p SET p.DaysWorked = 30-
		(SELECT COUNT(*) 
			FROM Attendance a 
			WHERE MONTH(a.LeaveDate)=@month 
				AND YEAR(a.LeaveDate)=@year 
				AND a.EmpID = p.EmpID) 
	FROM #Pay p

	--Fetch the daily wage
	Update p SET p.Wages =  
	(SELECT TOP 1 w.Amount 
		FROM Wages w 
		WHERE w.WEF < @FirstOfMonth			
			AND w.EmpID = p.EmpID 
		ORDER BY w.WEF DESC) 
	FROM #Pay p

	--Fetch Advance taken (if any)
	Update p SET p.Advance =  
	(SELECT sum(Amount)
		FROM Advance a 
		WHERE MONTH(a.AdvDate) = @month 
			AND YEAR(a.AdvDate)=@year 
			AND a.EmpID = p.EmpID ) 
	FROM #Pay p

	--Fetch Bonus for those whose month it is
	--Update p SET p.Bonus =  
	--(SELECT Case When COALESCE(b.UsrBonus,0)>0 THEN b.UsrBonus  ELSE b.SysBonus END
	--	FROM Bonus b 
	--	WHERE b.Year=@year 
	--		AND b.EmpID = p.EmpID 
	--		AND b.Frozen =0) 
	--FROM #Pay p
	--WHERE p.BonusPayMonth = @month

	
	--Fetch Loan details
	CREATE TABLE #Loan (
	LoanID INT,
	EmpID INT,
	Amount DECIMAL(18,2),
	PayMonths INT,
	MonthlyAmt DECIMAL(18,2),
	AmountPaid DECIMAL(18,2),
	Cmt Varchar(50))

	INSERT INTO #Loan(LoanID,EmpID, Amount, PayMonths)
	SELECT l.LoanID, l.EmpID, l.Amount,  l.PayMonths
	FROM Loans l 
	WHERE l.PaidOff = 0
	AND l.[Default] = 0


	--update with the loanSkip records
	UPDATE l SET l.MonthlyAmt = (SELECT TOP 1 s.Amount FROM LoanSkip s 
	WHERE l.LoanID=s.LoanID 
		AND MONTH(s.PayDate) = @month
		AND YEAR(s.PayDate) = @year
		ORDER by PayDate DESC)
	FROM #Loan l
	
	--If no loan skip Records then update with the ususal monthly payments
	UPDATE lc SET MonthlyAmt = l.Amount/l.PayMonths
	FROM #Loan lc, Loans l
	WHERE lc.MonthlyAmt IS NULL
	AND lc.LoanID=l.LoanID

	--Clear out and then recreate records of LoanPay
	DELETE FROM LoanPay WHERE Frozen=0 AND GenMonth= @month AND GenYear=@year

	--Fetch existing frozen payments done against this loan
	UPDATE l SET l.AmountPaid = (SELECT SUM(p.Amount) FROM LoanPay p WHERE p.LoanID=l.LoanID AND p.Frozen=1)	
	FROM #Loan l

	--reenter LoanPay records based on what is being paid this month. To be frozen during Payroll freeze
	INSERT INTO LoanPay(LoanID, GenMonth, GenYear,Amount, Frozen)
	SELECT LoanID,@month,@year, MonthlyAmt,0
	FROM #Loan
	WHERE LoanID not in (SELECT LoanID FROM LoanPay WHERE GenMonth=@month AND GenYear =@year AND Frozen=1)

	--Find how much of the loan is already paid off: retained only for debug purposes
	UPDATE l SET l.AmountPaid = COALESCE(l.AmountPaid,0),
	Cmt = 'Due: ' + CAST(l.Amount - l.MonthlyAmt - COALESCE(l.AmountPaid,0) AS VARCHAR(15) ) + ' of ' + CAST(l.Amount AS VARCHAR(15))
	FROM #Loan l

	SELECT * FROM #Loan

	select EmpID, sum(MonthlyAmt), Cmt = 'Due: ' + CAST(sum(l.Amount) - sum(l.MonthlyAmt) - sum(COALESCE(l.AmountPaid,0)) AS VARCHAR(15) ) + ' of ' + CAST(sum(l.Amount) AS VARCHAR(15))
	from #Loan l Group by EmpID


	Update p SET p.LoanAmt =  l.la, p.LoanCmt = l.lc	
	FROM #Pay p INNER JOIN (SELECT EmpId as EmpID, sum(MonthlyAmt) as la, 'Due: ' + CAST(sum(Amount) - sum(MonthlyAmt) - sum(COALESCE(AmountPaid,0)) AS VARCHAR(15) ) + ' of ' + CAST(sum(Amount) AS VARCHAR(15)) as lc
		FROM #Loan Group by EmpID) l
	ON p.EmpID= l.EmpID
	
	
	--Calc Allowance: refresh data in the Payroll Allowance table
	DELETE FROM PayrollAllowance WHERE GenMonth= @month AND GenYear=@year AND Frozen=0

	INSERT INTO PayrollAllowance(EmpID,ATID, GenMonth, GenYear)
	SELECT distinct e.EmpID, a.ATID, @month, @year 
	FROM Employees e, Allowance a
	WHERE e.EmpTypeID = a.EmpTypeID
	AND e.EmpID NOT IN (SELECT EmpID FROM PayrollAllowance WHERE GenMonth=@month AND GenYear =@year AND Frozen=1)
	
	UPDATE p SET p.Amount = (SELECT TOP 1 ( CASE WHEN COALESCE(a.Amount,0)>0 THEN a.Amount ELSE COALESCE(PercOfWage,0)*y.DaysWorked END) as amt FROM Allowance a	WHERE p.ATID=a.ATID AND e.EmpTypeID=a.EmpTypeID AND  a.WEF< @FirstOfMonth ORDER BY a.WEF DESC)
		FROM PayrollAllowance p, #Pay y, Employees e
		WHERE p.GenMonth= @month AND p.GenYear=@year
		AND p.EmpID=y.EmpID
		AND p.EmpID=e.EmpID
		
	
	select * from PayrollAllowance

	--Put the sum total of allowances into payroll
	UPDATE p SET p.Allowance= (SELECT SUM(Amount) FROM PayrollAllowance a WHERE p.EmpID=a.EmpID AND GenMonth= @month AND GenYear=@year)
	FROM #Pay p

	--calc the total
	UPDATE #Pay SET Total = (Wages*DaysWorked)+COALESCE(Allowance,0)+COALESCE(Bonus,0)-COALESCE(Advance,0)-COALESCE(LoanAmt,0)

	--Finally update the real Payroll table from the #table
	DELETE FROM Payroll WHERE GenMonth=@month AND GenYear=@year AND Frozen = 0
	
	INSERT INTO Payroll(EmpID,GenMonth,GenYear,GenDate,Wages,DaysWorked,Allowance,Advance,Bonus,LoanAmt,LoanCmt, Total,BankName,BankAccount)
	SELECT EmpID,@month,@year,GETDATE(),Wages,DaysWorked,Allowance,Advance,Bonus,LoanAmt, LoanCmt, Total,BankName,BankAccount
	FROM #Pay
	WHERE EmpID NOT IN (SELECT EmpID FROM Payroll WHERE  GenMonth=@month AND GenYear=@year)
RETURN 0

GO
/****** Object:  StoredProcedure [dbo].[Get5yrBonus]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Get5yrBonus]
	 @yr int 
AS
	DECLARE @Bon TABLE(
	EmpID INT,
	EmpName VARCHAR(100),
	yr1 DECIMAL(18,2),
	yr2 DECIMAL(18,2),
	yr3 DECIMAL(18,2),
	yr4 DECIMAL(18,2),
	ThisYrSys DECIMAL(18,2),
	ThisYrUsr DECIMAL(18,2))

	EXEC GenBonus --ensure we have the latest sysbonus prices 

	INSERT INTO @Bon(EmpID, EmpName, ThisYrSys,ThisYrUsr)
	SELECT b.EmpID,e.Name, SysBonus,UsrBonus 
	FROM Bonus b, Employees e WHERE b.EmpID=e.EmpID
	AND [Year] = @yr

	--update data for each past year	
	UPDATE b SET  yr4 = CASE WHEN COALESCE(u.UsrBonus,0) >0 THEN u.UsrBonus ELSE u.SysBonus END
	FROM @Bon b, Bonus u
	WHERE b.EmpID=u.EmpID
	AND u.Year = @yr-1

	UPDATE b SET  yr3 = CASE WHEN COALESCE(u.UsrBonus,0) >0 THEN u.UsrBonus ELSE u.SysBonus END
	FROM @Bon b, Bonus u
	WHERE b.EmpID=u.EmpID
	AND u.Year = @yr-2

	UPDATE b SET  yr2 = CASE WHEN COALESCE(u.UsrBonus,0) >0 THEN u.UsrBonus ELSE u.SysBonus END
	FROM @Bon b, Bonus u
	WHERE b.EmpID=u.EmpID
	AND u.Year = @yr-3

	UPDATE b SET  yr1 = CASE WHEN COALESCE(u.UsrBonus,0) >0 THEN u.UsrBonus ELSE u.SysBonus END
	FROM @Bon b, Bonus u
	WHERE b.EmpID=u.EmpID
	AND u.Year = @yr-4

	SELECT * FROM @Bon
RETURN 0

GO
/****** Object:  StoredProcedure [dbo].[GetLoanHistory]    Script Date: 6/11/2017 5:25:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetLoanHistory]
(
	@EmpID int 	= 0
)
AS
BEGIN

--Fetch Loan details
	DECLARE @Loan TABLE(
	LoanID INT,	
	LoanDate Date,
	Amount DECIMAL(18,2),
	PayMonths INT,
	AmountPaid DECIMAL(18,2),
	EmpID INT,
	EmpName VARCHAR(100),
	Cmt Varchar(50))

	IF @EmpID = 0 
	BEGIN
		INSERT INTO @Loan(LoanID, LoanDate, Amount, PayMonths, EmpID)
		SELECT l.LoanID,LoanDate, l.Amount,  l.PayMonths, l.EmpID
		FROM Loans l 
		WHERE l.PaidOff = 0
		AND l.[Default]=0		
	END
	ELSE
	BEGIN
		INSERT INTO @Loan(LoanID, LoanDate, Amount, PayMonths, EmpID)
		SELECT l.LoanID,LoanDate, l.Amount,  l.PayMonths, l.EmpID
		FROM Loans l 
		WHERE l.PaidOff = 0
		AND l.[Default]=0
		AND l.EmpID=@EmpID
	END

	--Put the Emp Name
	UPDATE l SET l.EmpName=e.Name
	FROM @Loan l, Employees e
	WHERE l.EmpID=e.EmpID
	
	--Fetch existing frozen payments done against this loan
	UPDATE l SET l.AmountPaid = (SELECT SUM(p.Amount) FROM LoanPay p WHERE p.LoanID=l.LoanID AND p.Frozen=1)	
	FROM @Loan l


	--Find how much of the loan is already paid off: retained only for debug purposes
	UPDATE l SET l.AmountPaid = COALESCE(l.AmountPaid,0),
	Cmt = 'Due: ' + CAST(l.Amount - COALESCE(l.AmountPaid,0) AS VARCHAR(15) ) + ' of ' + CAST(l.Amount AS VARCHAR(15))
	FROM @Loan l

	SELECT LoanID, LoanDate, Amount,PayMonths,AmountPaid,EmpID,EmpName, Cmt FROM @Loan

END


GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'warn x days before emp doc expires' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Config', @level2type=N'COLUMN',@level2name=N'DocExpirePreWarning'
GO

insert into aspnetroles
values (1,'Boss')

insert into aspnetroles
values (2,'Anon')

insert into aspnetroles
values (3,'HR')

Insert into config
values(1,83,3,10,'PicDoc','HDFC Panjim')

insert into AspNetUsers(Id,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName)
values('5e3fc53d-7078-43c4-93a2-8a61555106ea','ra@ra.com',0,'AJwlv1ubdXEGkiEVM4GmvWjICjNI8Syjdx6iRfX6fv5j6/ReZXvYLA63Ib0TPZq8dg==','8a2f6cb1-64cb-46f5-9141-47641f3533ea',NULL,0,0,NULL,1,0,'ra@ra.com')

insert into AspNetUserRoles
values('5e3fc53d-7078-43c4-93a2-8a61555106ea',1)

USE [master]
GO
ALTER DATABASE [NTHR] SET  READ_WRITE 
GO

